document.addEventListener('submit',async function(event){
 const form=event.target;if(!form.matches('.cherries-booking'))return;event.preventDefault();
 if(!form.reportValidity())return;
 const status=form.querySelector('[role=status]'),button=form.querySelector('button[type=submit]'),values=new FormData(form);
 const ar=form.dataset.lang==='ar';button.disabled=true;status.textContent='';status.dataset.error='false';
 const body=Object.fromEntries(values.entries());body.consent=values.get('consent')==='on';body.token=window.cherriesBooking.token;
 try{const response=await fetch(window.cherriesBooking.url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
 if(!response.ok)throw new Error('save');status.textContent=form.dataset.success;form.reset();}
 catch(error){status.dataset.error='true';status.textContent=ar?'تعذر حفظ الطلب. حاول مجدداً أو تواصل عبر واتساب.':'Could not save your request. Retry or contact us via WhatsApp.';}
 finally{button.disabled=false;}
});
document.addEventListener('click',function(event){
 const link=event.target.closest('a[href^="#cherries-filter-"]');if(!link)return;
 const gallery=link.closest('#gallery');if(!gallery)return;event.preventDefault();
 const category=link.getAttribute('href').replace('#cherries-filter-','');
 gallery.querySelectorAll('.cherries-gallery-item').forEach(item=>{item.hidden=category!=='0'&&!item.classList.contains('cherries-category-'+category);});
 gallery.querySelectorAll('a[href^="#cherries-filter-"]').forEach(button=>button.setAttribute('aria-pressed',button===link?'true':'false'));
});
