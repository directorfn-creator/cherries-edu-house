<?php
if (!defined('ABSPATH')) { exit; }
class Cherries_Elementor_Booking extends \Elementor\Widget_Base {
    public function get_name() { return 'cherries_booking'; }
    public function get_title() { return 'Cherries Tour Booking / حجز زيارة'; }
    public function get_icon() { return 'eicon-form-horizontal'; }
    public function get_categories() { return array('general'); }
    protected function register_controls() {
        $this->start_controls_section('form_content', array('label' => 'Form content / محتوى النموذج'));
        $this->add_control('language', array('label' => 'Language', 'type' => \Elementor\Controls_Manager::SELECT, 'options' => array('en' => 'English', 'ar' => 'العربية'), 'default' => 'en'));
        $labels = array('nameLabel'=>'Parent or Guardian Name *','namePlaceholder'=>'Your name','phoneLabel'=>'Phone Number *','phonePlaceholder'=>'012 XXXX XXXX','programLabel'=>'Class of Interest','programSelectPlaceholder'=>'Select a class','preferredDateLabel'=>'Preferred Visit Date','timeLabel'=>'Best Time to Contact','timePlaceholder'=>'Mornings','messageLabel'=>'Message or Questions','messagePlaceholder'=>'Your questions','consentLabel'=>'I consent to being contacted about this nursery tour request.','submitBtn'=>'Submit Tour Request','whatsappInstant'=>'Chat on WhatsApp','successTitle'=>'Tour Request Received!','successMsg'=>'Your request has been saved. Our team will contact you to confirm your visit.','whatsappRedirectNote'=>'Contact us on WhatsApp for further questions.');
        foreach ($labels as $key => $default) { $this->add_control($key, array('label' => $key, 'type' => \Elementor\Controls_Manager::TEXTAREA, 'default' => $default)); }
        $this->add_control('program_options', array('label'=>'Programs (one per line) / الفصول','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>"Infants\nJuniors\nPreschool\nGeneral Inquiry"));
        $this->add_control('whatsapp_url', array('label'=>'WhatsApp link','type'=>\Elementor\Controls_Manager::URL,'default'=>array('url'=>'https://wa.me/201277604444')));
        $this->end_controls_section();
        $this->start_controls_section('form_style', array('label'=>'Form style / التصميم','tab'=>\Elementor\Controls_Manager::TAB_STYLE));
        $this->add_control('form_background', array('label'=>'Background','type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#FFFFFF','selectors'=>array('{{WRAPPER}} .cherries-booking'=>'background-color: {{VALUE}};')));
        $this->add_control('text_color', array('label'=>'Text color','type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#35442B','selectors'=>array('{{WRAPPER}} .cherries-booking'=>'color: {{VALUE}};')));
        $this->add_control('button_background', array('label'=>'Button color','type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#B6C94B','selectors'=>array('{{WRAPPER}} .cherries-booking button, {{WRAPPER}} .cherries-booking .whatsapp'=>'background-color: {{VALUE}};')));
        $this->add_responsive_control('form_padding', array('label'=>'Padding','type'=>\Elementor\Controls_Manager::DIMENSIONS,'size_units'=>array('px','em','%'),'selectors'=>array('{{WRAPPER}} .cherries-booking'=>'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};')));
        $this->add_control('form_radius', array('label'=>'Border radius','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>array('px'=>array('min'=>0,'max'=>80)),'selectors'=>array('{{WRAPPER}} .cherries-booking'=>'border-radius: {{SIZE}}{{UNIT}};')));
        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(),array('name'=>'form_typography','selector'=>'{{WRAPPER}} .cherries-booking'));
        $this->end_controls_section();
    }
    protected function render() {
        $s = $this->get_settings_for_display();
        $id = 'cherries-form-' . $this->get_id();
        echo '<form class="cherries-booking" data-lang="' . esc_attr($s['language']) . '" data-success="' . esc_attr($s['successTitle'] . ' ' . $s['successMsg']) . '">';
        $fields = array('parentName'=>array('nameLabel','namePlaceholder','text',true),'phone'=>array('phoneLabel','phonePlaceholder','tel',true));
        foreach ($fields as $name => $f) {
            echo '<label for="' . esc_attr($id . '-' . $name) . '">' . esc_html($s[$f[0]]) . '<input id="' . esc_attr($id . '-' . $name) . '" name="' . esc_attr($name) . '" type="' . esc_attr($f[2]) . '" placeholder="' . esc_attr($s[$f[1]]) . '" maxlength="300" autocomplete="' . ($name === 'phone' ? 'tel' : 'name') . '" required></label>';
        }
        echo '<label>' . esc_html($s['programLabel']) . '<select name="program"><option value="">' . esc_html($s['programSelectPlaceholder']) . '</option>';
        foreach (explode("\n", $s['program_options']) as $option) { if (trim($option) !== '') { echo '<option>' . esc_html(trim($option)) . '</option>'; } }
        echo '</select></label><label>' . esc_html($s['preferredDateLabel']) . '<input type="date" name="preferredDate"></label>';
        echo '<label class="wide">' . esc_html($s['timeLabel']) . '<input name="contactTime" maxlength="300" placeholder="' . esc_attr($s['timePlaceholder']) . '"></label>';
        echo '<label class="wide">' . esc_html($s['messageLabel']) . '<textarea name="message" rows="4" maxlength="5000" placeholder="' . esc_attr($s['messagePlaceholder']) . '"></textarea></label>';
        echo '<label class="consent wide"><input type="checkbox" name="consent" required><span>' . esc_html($s['consentLabel']) . '</span></label>';
        echo '<div class="wide"><button type="submit">' . esc_html($s['submitBtn']) . '</button> <a class="whatsapp" href="' . esc_url($s['whatsapp_url']['url']) . '" target="_blank" rel="noopener noreferrer">' . esc_html($s['whatsappInstant']) . '</a></div>';
        echo '<p class="wide" role="status" aria-live="polite"></p></form>';
    }
}
