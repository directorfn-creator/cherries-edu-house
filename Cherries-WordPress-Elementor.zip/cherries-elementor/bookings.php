<?php
if (!defined('ABSPATH')) { exit; }
add_action('init', function () {
    register_post_type('cherries_tour', array('labels' => array('name' => 'Tour Requests / طلبات الزيارة', 'singular_name' => 'Tour Request'), 'public' => false, 'show_ui' => true, 'show_in_rest' => false, 'supports' => array('title'), 'capability_type' => 'post', 'capabilities' => array('create_posts' => 'do_not_allow'), 'map_meta_cap' => true));
});
add_action('add_meta_boxes', function () {
    add_meta_box('cherries-tour-data', 'Request details / تفاصيل الطلب', function ($post) {
        foreach ((array) get_post_meta($post->ID, '_cherries_request', true) as $key => $value) {
            echo '<p><strong>' . esc_html($key) . ':</strong> ' . nl2br(esc_html((string) $value)) . '</p>';
        }
    }, 'cherries_tour');
});
add_action('rest_api_init', function () {
    register_rest_route('cherries/v1', '/tours', array('methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'cherries_book'));
});
function cherries_book($request) {
    $body = $request->get_json_params();
    if (!is_array($body)) { return new WP_Error('invalid', 'Invalid request', array('status' => 400)); }
    $token = isset($body['token']) && is_string($body['token']) ? explode('.', $body['token'], 2) : array();
    $tick = (int) floor(time() / 43200);
    if (count($token) !== 2 || !ctype_digit($token[0]) || abs($tick - (int) $token[0]) > 1 || !hash_equals(hash_hmac('sha256', $token[0], wp_salt('nonce')), $token[1])) { return new WP_Error('expired', 'Refresh the page and retry.', array('status' => 403)); }
    $data = array();
    foreach (array('parentName','phone','program','preferredDate','contactTime','message') as $key) {
        if (isset($body[$key]) && !is_string($body[$key])) { return new WP_Error('invalid', 'Invalid field', array('status' => 400)); }
        $value = $body[$key] ?? '';
        if (strlen($value) > ($key === 'message' ? 5000 : 300)) { return new WP_Error('invalid', 'Field too long', array('status' => 400)); }
        $data[$key] = sanitize_textarea_field($value);
    }
    if (!$data['parentName'] || !preg_match('/^[+\d\s()\-]{7,30}$/u', $data['phone']) || ($body['consent'] ?? false) !== true) { return new WP_Error('invalid', 'Name, valid phone and consent are required.', array('status' => 400)); }
    if ($data['preferredDate'] && (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data['preferredDate']) || !strtotime($data['preferredDate']))) { return new WP_Error('invalid', 'Invalid visit date', array('status' => 400)); }
    // Do not trust forwarded IP headers. Hash the address; never store it with a booking.
    $rate_key = 'cherries_rate_' . hash_hmac('sha256', $_SERVER['REMOTE_ADDR'] ?? 'local', wp_salt());
    $count = (int) get_transient($rate_key);
    if ($count >= 5) { return new WP_Error('rate_limit', 'Please retry later or use WhatsApp.', array('status' => 429)); }
    $id = wp_insert_post(array('post_type' => 'cherries_tour', 'post_status' => 'private', 'post_title' => $data['parentName'] . ' — ' . current_time('Y-m-d H:i')), true);
    if (is_wp_error($id)) { return new WP_Error('storage', 'Could not save request', array('status' => 500)); }
    $data['consent'] = 'yes';
    update_post_meta($id, '_cherries_request', $data);
    set_transient($rate_key, $count + 1, HOUR_IN_SECONDS);
    return new WP_REST_Response(array('saved' => true), 201);
}
