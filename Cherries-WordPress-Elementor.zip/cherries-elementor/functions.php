<?php
if (!defined('ABSPATH')) { exit; }
require_once __DIR__ . '/bookings.php';
add_action('after_setup_theme', function () { add_theme_support('title-tag'); add_theme_support('post-thumbnails'); add_theme_support('elementor'); });
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('cherries-fonts', 'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Tajawal:wght@400;500;700;800&display=swap', array(), null);
    wp_enqueue_style('cherries-elementor', get_template_directory_uri() . '/assets/site.css', array(), '2.0.0');
    wp_enqueue_script('cherries-elementor', get_template_directory_uri() . '/assets/site.js', array(), '2.0.0', true);
    $tick = (string) floor(time() / 43200);
    wp_add_inline_script('cherries-elementor', 'window.cherriesBooking=' . wp_json_encode(array('url' => rest_url('cherries/v1/tours'), 'token' => $tick . '.' . hash_hmac('sha256', $tick, wp_salt('nonce'))), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ';', 'before');
});
add_filter('language_attributes', function ($attributes) {
    $lang = get_post_meta(get_queried_object_id(), '_cherries_language', true);
    if ($lang === 'ar') { return 'lang="ar" dir="rtl"'; }
    if ($lang === 'en') { return 'lang="en" dir="ltr"'; }
    return $attributes;
});
add_action('elementor/widgets/register', function ($manager) {
    require_once __DIR__ . '/widget-booking.php';
    $manager->register(new Cherries_Elementor_Booking());
});
add_action('admin_menu', function () { add_theme_page('Cherries Elementor', 'Cherries Elementor', 'manage_options', 'cherries-elementor', 'cherries_elementor_setup'); });
add_action('admin_notices', function () {
    if (current_user_can('manage_options') && !did_action('elementor/loaded')) {
        echo '<div class="notice notice-warning"><p>Cherries: Install and activate the free Elementor Website Builder plugin, then open Appearance → Cherries Elementor. / ثبّت وفعّل Elementor المجاني ثم افتح المظهر ← Cherries Elementor.</p></div>';
    }
});
function cherries_replace_links($value, $links) {
    if (is_array($value)) { foreach ($value as $key => $item) { $value[$key] = cherries_replace_links($item, $links); } return $value; }
    return is_string($value) ? strtr($value, $links) : $value;
}
function cherries_elementor_import($make_front = false) {
    if (!current_user_can('manage_options') || !did_action('elementor/loaded')) { return new WP_Error('elementor_missing', 'Activate Elementor Free first.'); }
    $ids = (array) get_option('cherries_elementor_pages_v2', array());
    foreach (array('en', 'ar') as $lang) {
        // Repeated imports never overwrite a page edited by the owner.
        if (!empty($ids[$lang]) && get_post_type($ids[$lang]) === 'page' && get_post_status($ids[$lang]) !== 'trash') { continue; }
        $id = wp_insert_post(array('post_type' => 'page', 'post_status' => 'publish', 'post_title' => $lang === 'ar' ? 'تشيريز — الرئيسية' : 'Cherries — Home', 'post_name' => 'cherries-' . $lang), true);
        if (is_wp_error($id)) { return $id; }
        $ids[$lang] = $id;
        update_post_meta($id, '_cherries_language', $lang);
        // Persist ownership immediately, so an interrupted import can resume.
        update_option('cherries_elementor_pages_v2', $ids, false);
    }
    $links = array('CHERRIES_EN_URL' => get_permalink($ids['en']), 'CHERRIES_AR_URL' => get_permalink($ids['ar']));
    foreach ($ids as $lang => $id) {
        if (!in_array($lang, array('en', 'ar'), true) || get_post_meta($id, '_cherries_import_complete', true)) { continue; }
        $template = json_decode(file_get_contents(__DIR__ . '/templates/cherries-' . $lang . '.json'), true);
        $document = \Elementor\Plugin::$instance->documents->get($id);
        if (!$document) { return new WP_Error('document', 'Could not create Elementor document.'); }
        $saved = $document->save(array('elements' => cherries_replace_links($template['content'], $links), 'settings' => $template['page_settings']));
        if (!$saved) { return new WP_Error('save', 'Could not save Elementor document.'); }
        update_post_meta($id, '_elementor_edit_mode', 'builder');
        update_post_meta($id, '_elementor_template_type', 'wp-page');
        update_post_meta($id, '_cherries_import_complete', '1');
    }
    if ($make_front) { update_option('show_on_front', 'page'); update_option('page_on_front', $ids['en']); }
    \Elementor\Plugin::$instance->files_manager->clear_cache();
    return $ids;
}
function cherries_elementor_setup() {
    if (!current_user_can('manage_options')) { return; }
    echo '<div class="wrap"><h1>Cherries — Elementor</h1><p>Install Elementor Free first. Import creates two native Elementor pages (English and Arabic). Existing edits are preserved on repeat import. / الاستيراد ينشئ صفحتين قابلة للتعديل بعناصر إليمنتور فعلية ويحافظ على التعديلات عند تكراره.</p>';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        check_admin_referer('cherries_elementor_import');
        $result = cherries_elementor_import(!empty($_POST['make_front']));
        if (is_wp_error($result)) { echo '<div class="notice notice-error"><p>' . esc_html($result->get_error_message()) . '</p></div>'; }
        else { echo '<div class="notice notice-success"><p>Pages imported / تم استيراد الصفحات</p></div>'; }
    }
    echo '<form method="post">'; wp_nonce_field('cherries_elementor_import');
    echo '<p><label><input type="checkbox" name="make_front" value="1"> Set English as homepage / تعيين الصفحة الإنجليزية كرئيسية</label></p>';
    submit_button('Import Cherries pages / استيراد صفحات تشيريز'); echo '</form>';
    foreach ((array) get_option('cherries_elementor_pages_v2', array()) as $lang => $id) {
        echo '<p>' . esc_html(strtoupper($lang)) . ': <a href="' . esc_url(admin_url('post.php?post=' . (int) $id . '&action=elementor')) . '">Edit with Elementor / تعديل بواسطة إليمنتور</a> · <a href="' . esc_url(get_permalink($id)) . '">View / عرض</a></p>';
    }
    echo '<p>Choose the Arabic homepage instead at Settings → Reading. Images currently reference the original external URLs. Replace them using each image widget’s media selector. / يمكنك اختيار العربية كرئيسية من الإعدادات ← قراءة. استبدل الصور من منتقي الوسائط داخل كل عنصر صورة.</p></div>';
}
